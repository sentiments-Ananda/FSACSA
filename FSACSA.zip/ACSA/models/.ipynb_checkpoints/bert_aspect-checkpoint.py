# -*- coding: utf-8 -*-
# file: BERT_SPC.py
# author: songyouwei <youwei0314@gmail.com>
# Copyright (C) 2019. All Rights Reserved.
import torch
import torch.nn as nn
from layers.induction_layer import Induction
from layers.relation import Relation


class BERT_ASPECT(nn.Module):
    def __init__(self, bert, opt):
        super(BERT_ASPECT, self).__init__()
        self.bert = bert
        opt.feature_dim = opt.bert_dim
        self.induction = Induction(opt)
        self.relation = Relation(opt)

    def forward(self, x):
        sentence,masked_sentence,seed_words,bert_segments_ids,supportset_size = x
        num_support = supportset_size.item()
        #_, sentence_support_encoder
        
        support_dict = self.bert(sentence[:num_support],token_type_ids=bert_segments_ids[:num_support])
        query_dict = self.bert(sentence[num_support:],token_type_ids=bert_segments_ids[num_support:])  # (k*c, 2*hidden_size)
        

        support_encoder = support_dict.pooler_output
        query_encoder = query_dict.pooler_output
        class_vector = self.induction(support_encoder)
        probs = self.relation(class_vector, query_encoder)
        '''
        support_encoder:  torch.Size([45, 768])
        query_encoder:  torch.Size([90, 768])
        class_vector:  torch.Size([3, 768])
        probs:  torch.Size([90, 3])
        '''
        return probs
