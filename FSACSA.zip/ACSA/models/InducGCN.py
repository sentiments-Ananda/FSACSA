
from torchtools import *
from collections import OrderedDict
import math
#import seaborn as sns
import numpy as np
import torch.nn as nn
import torch
import torch.nn.functional as F
#import matplotlib.pyplot as plt

class NodeNetwork(nn.Module):
    def __init__(self, in_features):
        super(NodeNetwork, self).__init__()
        self.in_features = in_features
        self.fc = nn.Linear(self.in_features, self.in_features)
        self.layernorm = nn.LayerNorm(self.in_features)
        self.relu = nn.LeakyReLU(0.3, inplace=True)
        self.net = nn.Sequential(
                       nn.Linear(3 * self.in_features, self.in_features),
                       self.layernorm,
                       self.relu,
        )

    def forward(self, x, residual):
        x = self.net(x)
        out = self.fc(x)
        out = self.layernorm(out)
        out += residual
        out = self.relu(out)
        out = self.fc(out)
        
        return out


class Sim_EdgeNetwork(nn.Module):
    def __init__(self, in_features):
        super(Sim_EdgeNetwork, self).__init__()
        self.in_features = in_features
        self.fc = nn.Linear(self.in_features, self.in_features)
        self.layernorm = nn.LayerNorm(self.in_features)
        self.relu = nn.LeakyReLU(0.3, inplace=True)
        self.fc_map = nn.Linear(self.in_features, 1)
        '''
        self.net = nn.Sequential(
                       nn.Linear(self.in_features, self.in_features),
                       self.layernorm,
                       self.relu,
                       nn.Linear(self.in_features, 1),
        )
        '''
        self.net = nn.Sequential(
            nn.Linear(self.in_features, self.in_features),
            nn.LayerNorm(self.in_features),
            nn.LeakyReLU(0.3, inplace=True),
        )
        self.arithm_sim = torch.max


    def residual_net(self, x, residual):
        out = self.fc(x)
        out = self.layernorm(out)

        out += residual
        out = self.relu(out)

        return out

    def forward(self, node_feat):
        '''
        node_feat:  torch.Size([90, 46, 768])
        '''
        x_i = node_feat.unsqueeze(2)
        x_j = torch.transpose(x_i, 1, 2)
        #x_ij = torch.abs(x_i - x_j)
        x_ij = x_i - x_j
        #x_ij = torch.transpose(x_ij, 1, 3)
        #print('x_i: ', x_i.size())     # torch.Size([90, 46, 1, 768])
        #print('x_j: ', x_j.size())     # torch.Size([90, 1, 46, 768])
        #print('x_ij: ', x_ij.size())   # torch.Size([90, 46, 46, 768])
        #out = torch.cat((x_i, x_j, x_ij), dim=-1)

        out = self.net(x_ij)
        #print('out: ', out.size())   # torch.Size([90, 46, 46, 768])
        res = self.arithm_sim(x_i, x_j)   
        #print('res: ', res.size())
        out = self.residual_net(out, res)  
        #print('out: ', out.size())    # # torch.Size([90, 46, 46, 768])
        out = self.fc_map(out)
        #print('out: ', out.size())       #  torch.Size([90, 46, 46, 1])
        out = torch.transpose(out, 1, 3)
        #print('x: ', x.size()) 
        #print('out: ', out.size())   # torch.Size([90, 1, 46, 46])
        return out

class Dis_EdgeNetwork(nn.Module):
    def __init__(self, in_features):
        super(Dis_EdgeNetwork, self).__init__()
        self.in_features = in_features
        self.fc = nn.Linear(self.in_features, self.in_features)
        self.layernorm = nn.LayerNorm(self.in_features)
        self.relu = nn.LeakyReLU(0.3, inplace=True)
        self.fc_map = nn.Linear(self.in_features, 1)
        '''
        self.net = nn.Sequential(
                       nn.Linear(self.in_features, self.in_features),
                       self.layernorm,
                       self.relu,
                       nn.Linear(self.in_features, 1),
        )
        '''
        self.net = nn.Sequential(
            nn.Linear(self.in_features, self.in_features),
            nn.LayerNorm(self.in_features),
            nn.LeakyReLU(0.3, inplace=True),
        )
        self.arithm_dis = torch.min

    def residual_net(self, x, residual):
        out = self.fc(x)
        out = self.layernorm(out)

        out += residual
        out = self.relu(out)

        return out

    def forward(self, node_feat):
        '''
        node_feat:  torch.Size([90, 46, 768])
        '''
        x_i = node_feat.unsqueeze(2)
        x_j = torch.transpose(x_i, 1, 2)
        x_ij = torch.abs(x_i - x_j)
        #x_ij = torch.transpose(x_ij, 1, 3)
        #print('x_i: ', x_i.size())     # torch.Size([90, 46, 1, 768])
        #print('x_j: ', x_j.size())     # torch.Size([90, 46, 1, 768])
        #print('x_ij: ', x_ij.size())   # torch.Size([90, 46, 46, 768])
        #out = torch.cat((x_i, x_j, x_ij), dim=-1)

        out = self.net(x_ij)
        #print('out: ', out.size())   # torch.Size([90, 46, 46, 768])
        res = self.arithm_dis(x_i, x_j)   
        #print('res: ', res.size())
        out = self.residual_net(out, res)  
        #print('out: ', out.size())    # # torch.Size([90, 46, 46, 768])
        out = self.fc_map(out)
        #print('out: ', out.size())       #  torch.Size([90, 46, 46, 1])
        out = torch.transpose(out, 1, 3)
        #print('x: ', x.size()) 
        #print('out: ', out.size())   # torch.Size([90, 1, 46, 46])
        
        return out

class NodeUpdateNetwork(nn.Module):
    def __init__(self, device):
        super(NodeUpdateNetwork, self).__init__()
        self.device = device
        self.network = NodeNetwork(in_features = 768)
        
    def forward(self, node_feat, edge_feat):
        # get size
        #print('node_feat: ', node_feat.size())
        #print('edge_feat: ', edge_feat.size())
        '''
        node_feat:  torch.Size([90, 46, 768])
        edge_feat:  torch.Size([90, 2, 46, 46])
        '''
        num_tasks = node_feat.size(0)
        num_data = node_feat.size(1)

        # get eye matrix (batch_size x 2 x node_size x node_size)
        diag_mask = 1.0 - torch.eye(num_data).unsqueeze(0).unsqueeze(0).repeat(num_tasks, 2, 1, 1).to(self.device)
        '''
        diag_mask:   torch.Size([90, 2, 46, 46]) 
        '''
        #print('diag_mask: ', diag_mask.size())

        # set diagonal as zero and normalize
        # 忽视自己跟自己的特征
        edge_feat = F.normalize(edge_feat * diag_mask, dim=-1)
        #print('edge_feat: ', edge_feat.size())
        # compute attention and aggregate
        '''
        edge_feat:   torch.Size([90, 2, 46, 46])
        node_feat:   torch.Size([90, 46, 768])
        '''
        #print(torch.cat(torch.split(edge_feat, 1, 1), 2).squeeze(1).size())
        #print('node_feat: ', node_feat.size())
        aggr_feat = torch.bmm(torch.cat(torch.split(edge_feat, 1, 1), 2).squeeze(1), node_feat)
        #print('aggr_feat: ', aggr_feat.size())
        '''
        aggr_feat:  torch.Size([90, 92, 768])
        '''
        ext_node_feat = torch.cat([node_feat, torch.cat(aggr_feat.split(num_data, 1), -1)], -1)
        #print('node_feat: ', node_feat.size())
        '''
        ext_node_feat:  torch.Size([90, 46, 2304])
        '''
        # non-linear transform
        node_feat = self.network(x = ext_node_feat, residual = node_feat)
        #node_feat = torch.randn(135, 768)
        #print('node_feat: ', node_feat.size())
        '''
        node_feat:  torch.Size([90, 46, 768])
        '''
        return node_feat


class EdgeUpdateNetwork(nn.Module):
    def __init__(self, device):
        super(EdgeUpdateNetwork, self).__init__()
        self.device = device
        self.sim_network = Sim_EdgeNetwork(in_features = 768)
        self.separate_dissimilarity = True
        self.dsim_network = Dis_EdgeNetwork(in_features = 768)

    def forward(self, node_feat, edge_feat):
        # compute abs(x_i, x_j)
        #print('node_feat: ', node_feat.size())
        #print('edge_feat: ', edge_feat.size())
        '''
        node_feat:  torch.Size([90, 46, 768])
        edge_feat:  torch.Size([90, 2, 46, 46])
        '''
        
        sim_val = self.sim_network(node_feat)
        '''
        sim_val:  torch.Size([90, 1, 46, 46])
        '''
        #sim_val = torch.randn(1, 135, 135)
        #print('sim_val: ', sim_val.size())
        if self.separate_dissimilarity:
            dsim_val = self.dsim_network(node_feat)
        else:
            dsim_val = 1.0 - sim_val
    
        diag_mask = 1.0 - torch.eye(node_feat.size(1)).unsqueeze(0).unsqueeze(0).repeat(node_feat.size(0), 2, 1, 1).to(self.device)
        edge_feat = edge_feat * diag_mask
        #print('diag_mask: ', diag_mask.size())
        #print('edge_feat: ', edge_feat.size())
        #print('dsim_val: ', dsim_val.size())
        #print('merge_sum: ', merge_sum.size())
        '''
        sim_val:  torch.Size([90, 1, 46, 46])
        diag_mask:  torch.Size([90, 2, 46, 46])
        edge_feat:  torch.Size([90, 2, 46, 46])
        dsim_val:  torch.Size([90, 1, 46, 46])
        merge_sum:  torch.Size([90, 2, 46, 1])
        '''
        # set diagonal as zero and normalize
        '''
        if edge_feat.size(-1)==4:
            print(edge_feat)
            #p()
        '''
        edge_feat = F.normalize(torch.cat([sim_val, dsim_val], 1), dim=-1)
        '''
        edge_feat:  torch.Size([90, 2, 46, 46])
        '''
        #print('edge_feat: ', edge_feat.size())
        
        #print('torch.eye(node_feat.size(0)).unsqueeze(0): ', torch.eye(node_feat.size(0)).unsqueeze(0).size())
        #print('.....', torch.zeros(node_feat.size(0), node_feat.size(0)).unsqueeze(0).size())
        force_edge_feat = torch.cat((torch.eye(node_feat.size(1)).unsqueeze(0), -torch.eye(node_feat.size(1), node_feat.size(1)).unsqueeze(0)), 0).unsqueeze(0).repeat(node_feat.size(0), 1, 1, 1).to(self.device)
        #print('force_edge_feat: ', force_edge_feat.size())
        '''
        force_edge_feat:  torch.Size([90, 2, 46, 46])
        '''
        
        edge_feat = edge_feat + force_edge_feat
        
        edge_feat = edge_feat + 1e-6
        
        #print('edge_feat: ', edge_feat.size())
        #print((edge_feat / torch.sum(edge_feat, dim=0)).unsqueeze(1).size())
        edge_feat = F.normalize(edge_feat, -1)
         
        '''
        edge_feat:  torch.Size([90, 2, 46, 46])
        '''
        #print('edge_feat: ', edge_feat.size())
        return edge_feat

class ProtoUpdateNetwork(nn.Module):
    def __init__(self, device, n_way):
        super(ProtoUpdateNetwork, self).__init__()
        self.device = device
        self.n_way = n_way
        self.W = torch.nn.Linear(768, self.n_way + 1, bias= True).to(self.device)

    def forward(self, node_feat, edge_feat):
        
        
        # compute abs(x_i, x_j)
        #print('node_feat: ', node_feat.size())
        #print('edge_feat: ', edge_feat.size())
        '''
        node_feat:  torch.Size([90, 46, 768])
        edge_feat:  torch.Size([90, 2, 46, 46])
        '''
        
        #print('aggr_feat: ', aggr_feat.size())
        P  = F.softmax(self.W(node_feat), -1)   # [90, 46, 4]
        #print(P[0,:,:])
        #p()
        #print('P: ', P.size())
        proto_node_feat = torch.matmul(P.transpose(1, 2), node_feat)    # [90, 4, 768])
        #print('proto_node_feat: ', proto_node_feat.size())

        #print('proto_node_feat: ', proto_node_feat.size())
        #计算原型矩阵
        
        x = torch.matmul(P.unsqueeze(1).repeat(1, 2, 1, 1).transpose(2, 3), edge_feat) # [90, 2, 4, 46])
        #print(x[0,0,:,:])
        #print(x[0,1,:,:])
        #p()
        
        #print('x: ', x.size())
        proto_edge = torch.matmul(x, P.unsqueeze(1).repeat(1, 2, 1, 1))   # [90, 2, 4, 4]
        #print('proto_edge: ', proto_edge.size()) 
        #p()
       
        
        return proto_node_feat, proto_edge




class Induc_GraphNetwork(nn.Module):
    def __init__(self, num_layers, device, n_way):
        super(Induc_GraphNetwork, self).__init__()

        self.num_layers = num_layers
        self.device = device
        self.n_way = n_way

        # for each layer
        for l in range(self.num_layers):
            # set edge to node
            edge2node_net = NodeUpdateNetwork(self.device)

            # set node to edge
            node2edge_net = EdgeUpdateNetwork(self.device)

            # set node and edge to proto
            proto_net = ProtoUpdateNetwork(self.device, self.n_way)

            self.add_module('edge2node_net{}'.format(l), edge2node_net)
            self.add_module('node2edge_net{}'.format(l), node2edge_net)
            self.add_module('proto_net{}'.format(l), proto_net)

    # forward
    def forward(self, node_feat, edge_feat):
        '''
        node_feat:  torch.Size([90, 46, 768])
        edge_feat:  torch.Size([90, 2, 46, 46])
        '''
        #print('node_feat: ', node_feat.size())
        #print('edge_feat: ', edge_feat.size())
        # for each layer
        proto_edge_list = []

        for l in range(self.num_layers):
            # (1) edge to node
            node_feat = self._modules['edge2node_net{}'.format(l)](node_feat, edge_feat)
            #print('node_feat: ', node_feat.size())   # torch.Size([90, 46, 768])
            # (2) node to edge
            edge_feat = self._modules['node2edge_net{}'.format(l)](node_feat, edge_feat)
            
            #print('edge_feat: ', edge_feat.size())   # torch.Size([90, 2, 46, 46])
            # (3) construct proto 
            proto_node_feat, proto_edge = self._modules['proto_net{}'.format(l)](node_feat, edge_feat)
            #print('proto_node_feat: ', proto_node_feat.size())   # [90, 4, 768]
            #print('proto_edge: ', proto_edge.size())   # [90, 2, 4, 4]
            # (4) proto node to proto edge

            proto_edge = self._modules['node2edge_net{}'.format(l)](proto_node_feat, proto_edge)

            #print('proto_edge: ', proto_edge.size())   #  [90, 2, 4, 4]
            #p()

            # save edge feature
            proto_edge_list.append(proto_edge) # 每层 [90, 2, 49, 49]


        return proto_edge_list


