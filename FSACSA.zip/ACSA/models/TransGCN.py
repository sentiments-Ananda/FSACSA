
from torchtools import *
from collections import OrderedDict
import math
#import seaborn as sns
import numpy as np
import torch.nn as nn
import torch
import torch.nn.functional as F
#import matplotlib.pyplot as plt

class NodeNetwork(nn.Module):
    def __init__(self, in_features):
        super(NodeNetwork, self).__init__()
        self.in_features = in_features
        self.fc = nn.Linear(self.in_features, self.in_features)
        self.layernorm = nn.LayerNorm(self.in_features)
        self.relu = nn.LeakyReLU(0.3, inplace=True)
        self.net = nn.Sequential(
                       nn.Linear(3 * self.in_features, self.in_features),
                       self.layernorm,
                       self.relu,
        )

    def forward(self, x, residual):
        x = self.net(x)
        out = self.fc(x)
        out = self.layernorm(out)
        out += residual
        out = self.relu(out)
        out = self.fc(out)
        
        return out



class Sim_EdgeNetwork(nn.Module):
    def __init__(self, in_features):
        super(Sim_EdgeNetwork, self).__init__()
        self.in_features = in_features
        self.fc = nn.Linear(self.in_features, self.in_features)
        self.layernorm = nn.LayerNorm(self.in_features)
        self.relu = nn.LeakyReLU(0.3, inplace=True)
        self.fc_map = nn.Linear(self.in_features, 1)
        '''
        self.net = nn.Sequential(
                       nn.Linear(self.in_features, self.in_features),
                       self.layernorm,
                       self.relu,
                       nn.Linear(self.in_features, 1),
        )
        '''
        self.net = nn.Sequential(
            nn.Linear(self.in_features, self.in_features),
            nn.LayerNorm(self.in_features),
            nn.LeakyReLU(0.3, inplace=True),
        )
        self.arithm_sim = torch.max

    def residual_net(self, x, residual):
        out = self.fc(x)
        out = self.layernorm(out)

        out += residual
        out = self.relu(out)

        return out

    def forward(self, node_feat):
        '''
        node_feat:  torch.Size([135, 768])
        '''
        x_i = node_feat.unsqueeze(1)  # torch.Size([135, 1, 768])
        x_j = torch.transpose(x_i, 0, 1)   # torch.Size([1, 135, 768])
        #x_ij = torch.abs(x_i - x_j)
        x_ij = x_i - x_j                 # torch.Size([135, 135, 768])
        #print('x_ij: ', x_ij.size())

        out = self.net(x_ij)
        #print('out: ', out.size())   # torch.Size([135, 135, 768])
        res = self.arithm_sim(x_i, x_j)   
        #print('res: ', res.size())    #  torch.Size([135, 135, 768])
        out = self.residual_net(out, res)  
        #print('out: ', out.size())    #  torch.Size([135, 135, 768])
        out = self.fc_map(out)
        #print('out: ', out.size())       #    torch.Size([135, 135, 1])
        out = torch.transpose(out, 0, 2)
        #print('out: ', out.size())   # torch.Size([135, 1, 135])
        
        return out


class Dis_EdgeNetwork(nn.Module):
    def __init__(self, in_features):
        super(Dis_EdgeNetwork, self).__init__()
        self.in_features = in_features
        self.fc = nn.Linear(self.in_features, self.in_features)
        self.layernorm = nn.LayerNorm(self.in_features)
        self.relu = nn.LeakyReLU(0.3, inplace=True)
        self.fc_map = nn.Linear(self.in_features, 1)
        '''
        self.net = nn.Sequential(
                       nn.Linear(self.in_features, self.in_features),
                       self.layernorm,
                       self.relu,
                       nn.Linear(self.in_features, 1),
        )
        '''
        self.net = nn.Sequential(
            nn.Linear(self.in_features, self.in_features),
            nn.LayerNorm(self.in_features),
            nn.LeakyReLU(0.3, inplace=True),
        )
        self.arithm_dis = torch.min

    def residual_net(self, x, residual):
        out = self.fc(x)
        out = self.layernorm(out)

        out += residual
        out = self.relu(out)

        return out

    def forward(self, node_feat):
        '''
        node_feat:  torch.Size([135, 768])
        '''
        x_i = node_feat.unsqueeze(1)  # torch.Size([135, 1, 768])
        x_j = torch.transpose(x_i, 0, 1)   # torch.Size([1, 135, 768])
        #x_ij = torch.abs(x_i - x_j)
        x_ij = x_i - x_j                 # torch.Size([135, 135, 768])
        #print('x_ij: ', x_ij.size())

        out = self.net(x_ij)
        #print('out: ', out.size())   # torch.Size([135, 135, 768])
        res = self.arithm_dis(x_i, x_j)   
        #print('res: ', res.size())   # torch.Size([135, 135, 768])
        out = self.residual_net(out, res)  
        #print('out: ', out.size())    # torch.Size([135, 135, 768])
        out = self.fc_map(out)
        #print('out: ', out.size())       #  out:  torch.Size([135, 135, 1])
        out = torch.transpose(out, 0, 2)
        #print('out: ', out.size())   # torch.Size([1, 135, 135])
        
        return out


class EdgeNetwork_dis(nn.Module):
    def __init__(self):
        super(EdgeNetwork_dis, self).__init__()
        self.fc = nn.Linear(768, 1600)
        self.layer1 = nn.Sequential(
                        nn.Conv2d(64,64,kernel_size=3,padding=1),
                        nn.BatchNorm2d(64),
                        nn.ReLU(),
                        nn.MaxPool2d(kernel_size=2, padding=1))
        self.layer2 = nn.Sequential(
                        nn.Conv2d(64,1,kernel_size=3,padding=1),
                        nn.BatchNorm2d(1),
                        nn.ReLU(),
                        nn.MaxPool2d(kernel_size=2, padding=1))

        self.fc3 = nn.Linear(2*2, 8)
        self.fc4 = nn.Linear(8, 1)

        self.m0 = nn.MaxPool2d(2)            # max-pool without padding 
        self.m1 = nn.MaxPool2d(2, padding=1) # max-pool with padding

    def forward(self, node_feat):
        #node_feat:  torch.Size([135, 768])
        x = self.fc(node_feat)   # x:  torch.Size([135, 1600])
        x = x.view(-1,64,5,5)
        out = self.layer1(x)
        out = self.layer2(out)
        # flatten
        out = out.view(out.size(0),-1) 
        out = F.relu(self.fc3(out))
        out = self.fc4(out) # no relu
        sigma = out.view(out.size(0),-1) #   torch.Size([135, 1])
        #print('out; ', out.size())
        emb_all = node_feat / (sigma + 1e-6) # torch.Size([135, 768])
        #print('emb_all; ', emb_all.size())
        emb1    = torch.unsqueeze(emb_all, 1) # torch.Size([135, 1, 768])
        #print('emb1: ', emb1.size())
        emb2    = torch.unsqueeze(emb_all, 0) # torch.Size([1, 135, 768])
        #print('emb2: ', emb2.size())
        d       = ((emb1-emb2)**2).mean(2)   # torch.Size([135, 135])
        #print('d: ', d.size())
        W_ij       = torch.exp(-d/2)  # torch.Size([135, 135])
        #print('W: ', W.size())
        return W_ij.unsqueeze(0)


class EdgeNetwork_cos(nn.Module):
    def __init__(self):
        super(EdgeNetwork_cos, self).__init__()

    def forward(self, node_feat):
        #node_feat:  torch.Size([135, 768])
        node_feat = F.normalize(node_feat, dim = -1)
        out = torch.cosine_similarity(node_feat.unsqueeze(1), node_feat.unsqueeze(0), dim = 2)
        #print('out: ', out.size())
        return out.unsqueeze(0)



class NodeUpdateNetwork(nn.Module):
    def __init__(self, device):
        super(NodeUpdateNetwork, self).__init__()
        self.device = device
        self.network = NodeNetwork(in_features = 768)
        
        
    def forward(self, node_feat, edge_feat):
        # get size
        #print('node_feat: ', node_feat.size())
        #print('edge_feat: ', edge_feat.size())
        '''
        node_feat:  torch.Size([135, 768])
        edge_feat:  torch.Size([2, 135, 135])
        '''
        #num_tasks = node_feat.size(0)
        num_data = node_feat.size(0)

        # get eye matrix (batch_size x 2 x node_size x node_size)
        diag_mask = 1.0 - torch.eye(num_data).unsqueeze(0).repeat(2, 1, 1).to(self.device)
        '''
        diag_mask:  torch.Size([2, 135, 135])
        '''
        #print('diag_mask: ', diag_mask.size())

        # set diagonal as zero and normalize
        # 忽视自己跟自己的特征
        edge_feat = F.normalize(edge_feat * diag_mask, dim=-1)
        #print('edge_feat: ', edge_feat.size())
        # compute attention and aggregate
        '''
        edge_feat:  torch.Size([2, 135, 135])
        node_feat:  torch.Size([135, 768])
        '''
        #print(torch.cat(torch.split(edge_feat, 1, 0), 1).squeeze(0).size())
        #print('node_feat: ', node_feat.size())
        aggr_feat = torch.bmm(torch.cat(torch.split(edge_feat, 1, 0), 1).squeeze(0).unsqueeze(0), node_feat.unsqueeze(0)).squeeze(0)
        #print('aggr_feat: ', aggr_feat.size())
        '''
        aggr_feat:  torch.Size([270, 768])
        '''
        ext_node_feat = torch.cat([node_feat, torch.cat(aggr_feat.split(num_data, 0), -1)], -1)
        #print('node_feat: ', node_feat.size())
        '''
        node_feat:  torch.Size([135, 2304])
        '''
        # non-linear transform
        node_feat = self.network(x = ext_node_feat, residual = node_feat)
        #node_feat = torch.randn(135, 768)
        #print('node_feat: ', node_feat.size())
        '''
        node_feat:  torch.Size([135, 768])
        '''
        return node_feat


class EdgeUpdateNetwork(nn.Module):
    def __init__(self, device):
        super(EdgeUpdateNetwork, self).__init__()
        self.device = device
        self.sim_network = Sim_EdgeNetwork(in_features = 768)
        self.dsim_network = Dis_EdgeNetwork(in_features = 768)
        self.separate_dissimilarity = True
        #self.sim_network = EdgeNetwork_dis()
        #self.sim_network = EdgeNetwork_cos()


    def forward(self, node_feat, edge_feat):
        # compute abs(x_i, x_j)
        #print('node_feat: ', node_feat.size())
        #print('edge_feat: ', edge_feat.size())
        '''
        node_feat:  torch.Size([135, 768])
        edge_feat:  torch.Size([2, 135, 135])
        '''
        sim_val = F.sigmoid(self.sim_network(node_feat))

        #sim_val = torch.randn(1, 135, 135)
        #print('sim_val: ', sim_val.size())

        if self.separate_dissimilarity:
            dsim_val = F.sigmoid(self.dsim_network(node_feat))
        else:
            dsim_val = 1.0 - sim_val
        

        diag_mask = 1.0 - torch.eye(node_feat.size(0)).unsqueeze(0).repeat(2, 1, 1).to(self.device)
        
        edge_feat = edge_feat * diag_mask
        merge_sum = torch.sum(edge_feat, -1, True)
        #print('sim_val: ', sim_val.size())
        #print('diag_mask: ', diag_mask.size())
        #print('edge_feat: ', edge_feat.size())
        #print('dsim_val: ', dsim_val.size())
        #print('merge_sum: ', merge_sum.size())
        '''
        sim_val:  torch.Size([1, 135, 135])
        diag_mask:  torch.Size([2, 135, 135])
        edge_feat:  torch.Size([2, 135, 135])
        dsim_val:  torch.Size([1, 135, 135])
        merge_sum:  torch.Size([2, 135, 1])
        '''
        # set diagonal as zero and normalize
        edge_feat = F.normalize(torch.cat([sim_val, dsim_val], 0) * edge_feat, dim=-1) * merge_sum
        '''
        edge_feat:  torch.Size([2, 135, 135])
        '''
        #print('edge_feat: ', edge_feat.size())
        
        
        
        
        #print('torch.eye(node_feat.size(0)).unsqueeze(0): ', torch.eye(node_feat.size(0)).unsqueeze(0).size())
        #print('.....', torch.zeros(node_feat.size(0), node_feat.size(0)).unsqueeze(0).size())
        force_edge_feat = torch.cat((torch.eye(node_feat.size(0)).unsqueeze(0), torch.zeros(node_feat.size(0), node_feat.size(0)).unsqueeze(0)), 0).repeat(1, 1, 1).to(self.device)
        
        #print('force_edge_feat: ', force_edge_feat.size())
        '''
        force_edge_feat:  torch.Size([2, 8, 8])
        '''
        edge_feat = edge_feat + force_edge_feat
        edge_feat = edge_feat + 1e-6
        #print('edge_feat: ', edge_feat.size())
        #print((edge_feat / torch.sum(edge_feat, dim=0)).unsqueeze(1).size())
        edge_feat = edge_feat / torch.sum(edge_feat, dim=0).repeat(1, 1, 1)
        '''
        edge_feat:  torch.Size([2, 8, 8])
        '''
        #print('edge_feat: ', edge_feat.size())
        return edge_feat


class ProtoUpdateNetwork(nn.Module):
    def __init__(self, device, n_way):
        super(ProtoUpdateNetwork, self).__init__()
        self.device = device
        self.n_way = n_way

    def forward(self, num_queries, node_feat, edge_feat):

        self.W = torch.nn.Linear(768, self.n_way + num_queries, bias= True).to(self.device)
        # compute abs(x_i, x_j)
        #print('node_feat: ', node_feat.size())
        #print('edge_feat: ', edge_feat.size())
        '''
        node_feat:  torch.Size([135, 768])
        edge_feat:  torch.Size([2, 135, 135])
        '''
        
        P  = F.softmax(self.W(node_feat), -1)   #  torch.Size([135, 93])
        #print('P: ', P.size())
        proto_feat = torch.matmul(P.T, node_feat)  # torch.Size([90+3, 768]) 
        #print('proto_feat: ', proto_feat.size())
        #计算原型矩阵
        x = torch.matmul(P.unsqueeze(0).repeat(2, 1, 1).transpose(1, 2), edge_feat) # torch.Size([2, 93, 135])
        #print('x: ', x.size())
        proto_edge = torch.matmul(x, P.unsqueeze(0).repeat(2, 1, 1))   # torch.Size([2, 90+3, 90+3])
        #print('proto_edge: ', proto_edge.size())
        return proto_feat, proto_edge




class Trans_GraphNetwork(nn.Module):
    def __init__(self, num_layers, device, n_way):
        super(Trans_GraphNetwork, self).__init__()

        self.num_layers = num_layers
        self.device = device
        self.n_way = n_way

        # for each layer
        for l in range(self.num_layers):
            # set edge to node
            edge2node_net = NodeUpdateNetwork(self.device)

            # set node to edge
            node2edge_net = EdgeUpdateNetwork(self.device)

            # set node and edge to proto
            proto_net = ProtoUpdateNetwork(self.device, self.n_way)

            self.add_module('edge2node_net{}'.format(l), edge2node_net)
            self.add_module('node2edge_net{}'.format(l), node2edge_net)
            self.add_module('proto_net{}'.format(l), proto_net)

    # forward
    def forward(self, num_queries, node_feat, edge_feat):
        '''
        node_feat:  torch.Size([135, 768])
        edge_feat:  torch.Size([2, 135, 135])
        '''
        #print('node_feat: ', node_feat.size())
        #print('edge_feat: ', edge_feat.size())
        # for each layer
        edge_feat_list = []
        proto_edge_list = []
        for l in range(self.num_layers):
            # (1) edge to node
            node_feat = self._modules['edge2node_net{}'.format(l)](node_feat, edge_feat)

            # (2) node to edge
            edge_feat = self._modules['node2edge_net{}'.format(l)](node_feat, edge_feat)

            # (3) construct proto 
            proto_feat, proto_edge = self._modules['proto_net{}'.format(l)](num_queries, node_feat, edge_feat)
            
            # (4) proto node to proto edge

            proto_edge = self._modules['node2edge_net{}'.format(l)](proto_feat, proto_edge)

            # save edge feature
            edge_feat_list.append(edge_feat)
            proto_edge_list.append(proto_edge)



        return edge_feat_list, proto_edge_list