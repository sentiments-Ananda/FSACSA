# -*- coding: utf-8 -*-
# file: BERT_SPC.py
# author: songyouwei <youwei0314@gmail.com>
# Copyright (C) 2019. All Rights Reserved.
import torch
import torch.nn as nn
from fastNLP.modules import AvgPoolWithMask
from fastNLP import seq_len_to_mask
import numpy as np
from .InducGCN import Induc_GraphNetwork
from copy import deepcopy
import torch.nn.functional as F
from torch.nn.modules.loss import _Loss
torch.set_printoptions(threshold=np.inf)

class Criterion(_Loss):
    def __init__(self):
        super(Criterion, self).__init__()

    def forward(self, probs, target):  # (Q,C) (Q)
        target_onehot = torch.zeros_like(probs)
        target_onehot = target_onehot.scatter(1, target.reshape(-1, 1), 1)
        loss = torch.mean((probs - target_onehot) ** 2)
        return loss

class main_bert(nn.Module):
    def __init__(self, bert, opt):
        super(main_bert, self).__init__()
        self.bert = bert
        self.freeze_layers(numFreeze=8)
        self.pool = AvgPoolWithMask()
        self.device = opt.device
        self.num_layers = opt.num_layers
        self.edge_loss = nn.BCELoss(reduction='none')
        self.node_loss = Criterion()
        self.n_way = opt.n_way
        self.scale = opt.scale
        self.LN                 = torch.nn.LayerNorm(self.n_way)
        self.gnn_module = Induc_GraphNetwork(num_layers = self.num_layers, device = self.device, n_way = self.n_way)


    def freeze_layers(self, numFreeze):
        unfreeze_layers = ["pooler"]
        for i in range(numFreeze, 12):
            unfreeze_layers.append("layer."+str(i))

        for name, param in self.bert.named_parameters():
            param.requires_grad = False
            for ele in unfreeze_layers:
                if ele in name:
                    param.requires_grad = True
                    break

    def get_mask(self, src_tokens, src_seq_len):

        mask = seq_len_to_mask(src_seq_len, max_len=src_tokens.size(-1))
        return mask

    def get_data(self, x):
        sentence, sent_seq_len, bert_segments_ids, supportset_size = x
        mask = self.get_mask(src_tokens = sentence, src_seq_len = sent_seq_len)
        num_support = supportset_size.item()
        support_mask = mask[:num_support]   # torch.Size([45, 85])
        query_mask = mask[num_support:]
        
        support_dict = self.bert(sentence[:num_support],token_type_ids=bert_segments_ids[:num_support])
        query_dict = self.bert(sentence[num_support:],token_type_ids=bert_segments_ids[num_support:])  # (k*c, 2*hidden_size)
        
        #support_dict.last_hidden_state :  torch.Size([45, 85, 768])
        #support_dict.pooler_output :   torch.Size([45, 768])
        support_data = self.pool(support_dict.last_hidden_state, support_mask) # torch.Size([45, 768])
        query_data = self.pool(query_dict.last_hidden_state, query_mask)  # torch.Size([90, 768])
        
        return support_data, query_data
    
    def label2edge(self, label):
        '''
        label:  torch.Size([135])
        '''
        # get size
        num_samples = label.size(0)

        # reshape

        label_i = label.unsqueeze(-1).repeat(1, num_samples)
        label_j = label_i.transpose(0, 1)

        # compute edge
        edge = torch.eq(label_i, label_j).float().to(self.device)
        '''
        label = torch.tensor([0,0,0,1,1,1,0,1])
        edge:  tensor([[1., 1., 1., 0., 0., 0., 1., 0.],
                       [1., 1., 1., 0., 0., 0., 1., 0.],
                       [1., 1., 1., 0., 0., 0., 1., 0.],
                       [0., 0., 0., 1., 1., 1., 0., 1.],
                       [0., 0., 0., 1., 1., 1., 0., 1.],
                       [0., 0., 0., 1., 1., 1., 0., 1.],
                       [1., 1., 1., 0., 0., 0., 1., 0.],
                       [0., 0., 0., 1., 1., 1., 0., 1.]], device='cuda:0')
        '''
        # expand
        edge = edge.unsqueeze(0)
        edge = torch.cat([edge, 1 - edge], 0)
        assert edge.size(0) == 2 and edge.size(1) == edge.size(2) == num_samples
        '''
        edge:   tensor([[[1., 1., 1., 0., 0., 0., 1., 0.],
                         [1., 1., 1., 0., 0., 0., 1., 0.],
                         [1., 1., 1., 0., 0., 0., 1., 0.],
                         [0., 0., 0., 1., 1., 1., 0., 1.],
                         [0., 0., 0., 1., 1., 1., 0., 1.],
                         [0., 0., 0., 1., 1., 1., 0., 1.],
                         [1., 1., 1., 0., 0., 0., 1., 0.],
                         [0., 0., 0., 1., 1., 1., 0., 1.]],

                         [[0., 0., 0., 1., 1., 1., 0., 1.],
                          [0., 0., 0., 1., 1., 1., 0., 1.],
                          [0., 0., 0., 1., 1., 1., 0., 1.],
                          [1., 1., 1., 0., 0., 0., 1., 0.],
                          [1., 1., 1., 0., 0., 0., 1., 0.],
                          [1., 1., 1., 0., 0., 0., 1., 0.],
                          [0., 0., 0., 1., 1., 1., 0., 1.],
                          [1., 1., 1., 0., 0., 0., 1., 0.]]], device='cuda:0')
        '''
        return edge

    def get_edge(self, init_edge):
        num_non_quueries = self.num_supports
        init_edge[:, num_non_quueries:, :] = 0.5
        init_edge[:, :, num_non_quueries:] = 0.5
        '''
            init_edge:  tensor([[[1,   1,   1,   0,   0,   0,   0.5, 0.5],
                                 [1,   1,   1,   0,   0,   0,   0.5, 0.5],
                                 [1,   1,   1,   0,   0,   0,   0.5, 0.5],
                                 [0,   0,   0,   1,   1,   1,   0.5, 0.5],
                                 [0,   0,   0,   1,   1,   1,   0.5, 0.5],
                                 [0,   0,   0,   1,   1,   1,   0.5, 0.5],
                                 [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5],
                                 [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]],

                                [[0,  0,   0,   1,   1,   1,   0.5, 0.5],
                                 [0,   0,   0,   1,   1,   1,   0.5, 0.5],
                                 [0,   0,   0,   1,   1,   1,   0.5, 0.5],
                                 [1,   1,   1,   0,   0,   0,   0.5, 0.5],
                                 [1,   1,   1,   0,   0,   0,   0.5, 0.5],
                                 [1,   1,   1,   0,   0,   0,   0.5, 0.5],
                                 [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5],
                                 [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]]])
        '''
        for i in range(self.num_queries):
            init_edge[0, num_non_quueries + i, num_non_quueries + i] = 1.0
            init_edge[1, num_non_quueries + i, num_non_quueries + i] = 0.0
        '''
        init_edge:  tensor([[[1,   1,   1,   0,   0,   0,   0.5, 0.5],
                                [1,   1,   1,   0,   0,   0,   0.5, 0.5],
                                [1,   1,   1,   0,   0,   0,   0.5, 0.5],
                                [0,   0,   0,   1,   1,   1,   0.5, 0.5],
                                [0,   0,   0,   1,   1,   1,   0.5, 0.5],
                                [0,   0,   0,   1,   1,   1,   0.5, 0.5],
                                [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 1,   0.5],
                                [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 1]],

                            [[0,   0,   0,   1,   1,   1,   0.5,   0.5],
                                [0,   0,   0,   1,   1,   1,   0.5,   0.5],
                                [0,   0,   0,   1,   1,   1,   0.5,   0.5],
                                [1,   1,   1,   0,   0,   0,   0.5,   0.5],
                                [1,   1,   1,   0,   0,   0,   0.5,   0.5],
                                [1,   1,   1,   0,   0,   0,   0.5,   0.5],
                                [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0,     0.5],
                                [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5,   0]]])
        '''
        return init_edge


    def hit(self, logit, label):
        '''
        logit:  torch.Size([2, 8, 8])
        label:  torch.Size([8, 8])
        '''
        pred = logit.max(0)[1] #两个维度间看谁更大
        hit = torch.eq(pred, label).float()
        return hit

    def one_hot_encode(self, num_classes, class_idx):
        return torch.eye(num_classes)[class_idx].to(self.device)



    def layer(self, proto_feat_list):
        '''
        proto to query
        '''
        sum_num = self.num_protos + self.num_queries
        edge_mask = torch.zeros(sum_num, sum_num).to(self.device)
        evaluation_mask = torch.ones(sum_num, sum_num).to(self.device) 
        edge_mask[:self.num_protos, :self.num_protos] = 1
        query_edge_mask = 1 - edge_mask   #
        evaluation_mask[self.num_protos:, self.num_protos:] = 0   

        logit_layers = []  # logit_layers里每一层大小 [2, 138, 138] , 138 = 3 + 45 + 90
        for l in range(self.num_layers):
            logit_layers.append(torch.zeros(2, sum_num, sum_num).to(self.device))

        for l in range(self.num_layers):
            logit_layers[l][:, :self.num_protos, :self.num_protos] = proto_feat_list[l][:, :, :self.num_protos, :self.num_protos].mean(0)
            logit_layers[l][:, :self.num_protos, self.num_protos:] = proto_feat_list[l][:, :, :self.num_protos, -1].transpose(0, 1).transpose(1, 2) 
            logit_layers[l][:, self.num_protos:, :self.num_protos] = proto_feat_list[l][:, :, -1, :self.num_protos].transpose(0, 1)  
        
        # compute loss
        node_pred_layers = []
        labels = torch.cat([self.proto_label, self.support_label], -1)
    

        #print(logit_layers[0][0,self.num_protos:, :self.num_protos])
        for logit_layer in logit_layers:
            node_pred_layers.append(torch.bmm(logit_layer[0, self.num_protos:, :self.num_protos].unsqueeze(0), \
                                        self.one_hot_encode(self.n_way, self.proto_label.long()).unsqueeze(0)).squeeze(0))
        probs = node_pred_layers[-1]
        #print(probs)
        #loss = self.node_loss(probs = probs, target = self.query_label)
        probs = self.LN(probs)
        loss = self.main_loss(y_pred = probs, y_true = self.query_label)
        #loss = F.cross_entropy(probs, self.query_label)
        #print('p_probs: ', p_probs.size())  # torch.Size([90, 3])
        
        return probs, loss


    def main_loss(self, y_pred, y_true):
        #y_pred = torch.tensor([[0.1, 0.2, 0.3], [0.2, 0.4, 0.8]])
        #y_true = torch.tensor([0, 2])
        target_onehot = torch.zeros_like(y_pred)
        y_true = target_onehot.scatter(1, y_true.reshape(-1, 1), 1)

        #https://kexue.fm/archives/7359
        #y_pred = torch.tensor([[0.1, 0.2, 0.3], [0.2, 0.4, 0.8]])
        #y_true = torch.tensor([[1, 0, 0], [0, 0, 1]])

        y_pred = (1 - 2 * y_true) * y_pred
        y_pred_neg = y_pred - y_true * 1e12
        y_pred_pos = y_pred - (1 - y_true) * 1e12
        #print('y_pred: ', y_pred)
        #print('y_pred_neg: ', y_pred_neg)
        #print('y_pred_pos: ', y_pred_pos)
        zeros = torch.zeros_like(y_pred[..., :1])
        #print('zeros: ', zeros)
        y_pred_neg = torch.cat([y_pred_neg, zeros], axis=-1)
        y_pred_pos = torch.cat([y_pred_pos, zeros], axis=-1)
        
        # 0.1 从极值点跳出，
        # 0.5 也跳出，跳的更早，
        # single 0.01最好
        # multi 0.03最好  
        neg_loss = torch.logsumexp(y_pred_neg/self.scale, axis=-1)
        pos_loss = torch.logsumexp(y_pred_pos/self.scale, axis=-1)
        #print('neg_loss: ', neg_loss)
        loss = neg_loss + pos_loss
        return torch.mean(loss)
        

    def forward(self, x, labels):
        # 'concat_bert_indices', 'concat_seq_len', 'concat_segments_indices', 'supportset_size'
        support_data, query_data = self.get_data(x)

        self.num_protos = self.n_way
        self.num_supports = support_data.size(0)
        self.num_queries = query_data.size(0)
        #print('labels: ', labels.size())
        #p()
        self.proto_label = torch.arange(0, self.n_way).to(self.device)
        self.support_label = torch.tensor(labels[:self.num_supports]).to(self.device)   # torch.Size([45])
        self.query_label = torch.tensor(labels[self.num_supports:]).to(self.device)   # torch.Size([90])
        
        self.full_edge = self.label2edge(labels).squeeze(0)   # torch.Size([2, 135, 135]) 
        #print('full_edge: ', full_edge.size())
        # set init edge
        init_edge = self.get_edge(init_edge = self.full_edge)  # torch.Size([2, 135, 135])
        init_edge[init_edge==0] = -1
        init_edge[init_edge==0.5] = 0
        #print('init_edge: ', init_edge.size())

        support_data_tiled = support_data.repeat(self.num_queries, 1)  # torch.Size([4050, 768])
        #print('support_data_tiled: ', support_data_tiled.size())
        support_data_tiled = support_data_tiled.view(self.num_queries, self.num_supports, -1)   # torch.Size([90, 45, 768])
        #print('support_data_tiled: ', support_data_tiled.size())
        query_data_reshaped = query_data.contiguous().view(self.num_queries, -1).unsqueeze(1)  #  torch.Size([90, 1, 768])
        #print('query_data_reshaped: ', query_data_reshaped.size())
        input_node_feat = torch.cat([support_data_tiled, query_data_reshaped], 1)  #  torch.Size([90, 46, 768])
        #print('input_node_feat: ', input_node_feat.size())
        #input_edge_feat = 0.5 * torch.ones(2, self.num_supports + 1, self.num_supports + 1).to(self.device)  #  torch.Size([2, 46, 46])
        #print('input_edge_feat: ', input_edge_feat.size())
        input_edge_feat = init_edge[:, :self.num_supports + 1, :self.num_supports + 1]   # torch.Size([2, 46, 46])
        #print('input_edge_feat: ', input_edge_feat.size())
        input_edge_feat = input_edge_feat.repeat(self.num_queries, 1, 1, 1)   #  torch.Size([90, 2, 46, 46])
        #print('input_edge_feat: ', input_edge_feat.size())
        # input_node_feat [90, 46, 768]  ,   input_edge_feat [90, 2, 46, 46]
        proto_feat_list = self.gnn_module(node_feat = input_node_feat, edge_feat = input_edge_feat)
        # proto_feat_list 每层 [90, 2, 4, 4]
        probs, loss = self.layer(proto_feat_list)
        
        return loss, probs
