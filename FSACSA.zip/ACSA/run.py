import argparse
import pickle
import os
from tqdm import tqdm, trange
import torch
from torch import optim
import random
import numpy as np
from criterion import Criterion, CrossEntropyCriterion
from tensorboardX import SummaryWriter
from sklearn.metrics import f1_score, classification_report,accuracy_score
from collections import defaultdict
from data_utils import FewshotACSADataset,build_tokenizer,build_embedding_matrix,Tokenizer,AllAspectFewshotDataLoader, Tokenizer4Bert
from models.induction import FewShotInduction, AspectAwareInduction
from transformers import BertModel
from models.aspect_induction import AspectFewshot
from models.relation import FewShotRelation
from models.aspect_relation import AspectRelation
from models.cnn_relation import CNNRelation
from models.atae_lstm import ATAE_LSTM
from models.bert_spc import  BERT_SPC
from models.bert_aspect import BERT_ASPECT
from models.main_model import main_bert

import warnings
warnings.filterwarnings("ignore")
from transformers import logging
 
logging.set_verbosity_warning()
logging.set_verbosity_error()

class Instructor(object):
    def __init__(self,opt):
        self.opt = opt
        self.opt.supportset_size = opt.ways * opt.shots
        # total_tasks = self._get_tasks(os.path.join(opt.dataset_files['data_dir'],"total_tasks"))
        train_tasks = self._get_tasks(opt.dataset_files['train'])
        print(len(train_tasks), ' train_tasks: ', train_tasks)
        val_tasks = self._get_tasks(opt.dataset_files['val'])
        print(len(val_tasks), ' val_tasks: ', val_tasks)
        test_tasks = self._get_tasks(opt.dataset_files['test'])
        print(len(test_tasks),' test_tasks: ', test_tasks)
        
        train_fnames = self._get_file_names(opt.dataset_files['data_dir'], train_tasks)
        val_fnames = self._get_file_names(opt.dataset_files['data_dir'], val_tasks)
        test_fnames = self._get_file_names(opt.dataset_files['data_dir'], test_tasks)

        if 'bert' in opt.model_name:
            tokenizer = Tokenizer4Bert(opt.max_seq_len, opt.pretrained_bert_name)
            bert = BertModel.from_pretrained(opt.pretrained_bert_name)
            self.model = opt.model_class(bert, opt).to(opt.device)
        else:
            tokenizer = build_tokenizer(
                fnames=train_fnames + val_fnames + test_fnames,
                max_seq_len=self.opt.max_seq_len,
                dat_fname='{0}_tokenizer.dat'.format(opt.dataset))
            embedding_matrix = build_embedding_matrix(
                word2idx=tokenizer.word2idx,
                embed_dim=self.opt.embed_dim,
                dat_fname='{0}_{1}_embedding_matrix.dat'.format(str(300), self.opt.dataset))
            self.model = self.opt.model_class(embedding_matrix, opt).to(self.opt.device)
            print("tokenizer length: ", len(tokenizer.idx2word))
            print("embedding_matrix shape: ", embedding_matrix.shape)
        print("using model: ",opt.model_name)
        print("running dataset: ", opt.dataset)
        print("output_dir: ", opt.output_dir)
        print("shots: ", opt.shots)
        print("ways: ", opt.ways)
        data_dir = self.opt.dataset_files['data_dir']
        self.trainset = FewshotACSADataset(data_dir=data_dir, tasks=train_tasks,
                                      tokenizer=tokenizer,opt = self.opt)
        self.valset = FewshotACSADataset(data_dir=data_dir, tasks=val_tasks,
                                    tokenizer=tokenizer,opt = self.opt)
        self.testset = FewshotACSADataset(data_dir=data_dir, tasks=test_tasks,
                                     tokenizer=tokenizer,opt = self.opt)

        parameters = []
        params = {'lr':opt.lr, 'weight_decay':1e-2}
        params['params'] = [param for name, param in self.model.named_parameters() if not ('bert' in name)]
        parameters.append(params)

        params = {'lr':opt.lr, 'weight_decay':1e-2}
        params['params'] = []
        for name, param in self.model.named_parameters():
            if ('bert' in name or 'bert' in name) and not ('layernorm' in name or 'layer_norm' in name):
                params['params'].append(param)
        parameters.append(params)

        params = {'lr':opt.lr, 'weight_decay':0}
        params['params'] = []
        for name, param in self.model.named_parameters():
            if ('bert' in name or 'bert' in name) and ('layernorm' in name or 'layer_norm' in name):
                params['params'].append(param)
        parameters.append(params)

        self.optimizer = optim.AdamW(parameters)

        
        from transformers import get_linear_schedule_with_warmup
        t_total = opt.num_episode
        self.lr_scheduler = get_linear_schedule_with_warmup(self.optimizer, num_warmup_steps=opt.warmup, num_training_steps=t_total)

    def dev_across_tasks(self,episode,criterion):
        tasks = self.valset.tasks
        self.model.eval()
        correct = 0.
        count = 0.
        record_target = defaultdict(list)  # task_id:result
        record_pred = defaultdict(list) # task_id: result
        for i in trange(len(self.dev_loader)):
            batch = self.dev_loader.get_batch()
            num_support = batch['supportset_size'].item()
            input_features = [batch[feat_name].to(self.opt.device) for feat_name in self.opt.input_features]
            # data = batch['text_indices']
            target = batch['polarity']
            task_ids = batch['task_id'].cpu().tolist()
            # data = data.to(self.opt.device)
            target = target.to(self.opt.device)
            _, predict = self.model(input_features, target)
            predict, _, _, _ = criterion(predict, target,num_support=num_support)
            true = np.ndarray.tolist(target[num_support:].data.cpu().numpy())
            preds = np.ndarray.tolist(predict.data.cpu().numpy())
            task_ids = task_ids[num_support:]
            assert len(task_ids)==len(preds)==len(true), "Wrong target len!\n"
            for example_index, task_id in enumerate(task_ids):
                record_target[task_id].append(true[example_index])
                record_pred[task_id].append(preds[example_index])
        if self.dev_loader.type !='train':
            self.dev_loader.reset_test_loader() ## dev loader iterration over reset dev loader for next
        score_dict = {}
        total_f1,total_acc = 0,0
        assert len(tasks)==len(record_target),"dataloader tasks not equal"
        for task_id, targets in record_target.items():
            preds = record_pred[task_id]
            task_f1 = f1_score(targets,preds,average='macro')
            task_acc = accuracy_score(targets,preds)
            score_dict[tasks[task_id]] = {"f1":task_f1,"acc":task_acc}
            total_f1 += task_f1
            total_acc += task_acc
        acc = total_acc / len(record_target)
        f1 = total_f1/len(record_target)
        print('Dev Episode: {} Acc: {} F1: {}'.format(episode, acc, f1))
        return f1, acc



    def test_across_tasks(self,criterion):
        tasks = self.testset.tasks
        self.model.eval()
        correct = 0.
        count = 0.
        record_target = defaultdict(list)  # task_id:result
        record_pred = defaultdict(list)  # task_id: result
            
        for idx in trange(len(self.test_loader)):
            batch = self.test_loader.get_batch()
            num_support = batch['supportset_size'].item()
            input_features = [batch[feat_name].to(self.opt.device) for feat_name in self.opt.input_features]
            # data = batch['text_indices']
            target = batch['polarity']
            task_ids = batch['task_id'].cpu().tolist()
            # data = data.to(self.opt.device)
            target = target.to(self.opt.device)
            _, predict = self.model(input_features, target)
            predict, _, acc, _ = criterion(predict, target,num_support=num_support)
            true = np.ndarray.tolist(target[num_support:].data.cpu().numpy())
            preds = np.ndarray.tolist(predict.data.cpu().numpy())
            task_ids = task_ids[num_support:]
            assert len(task_ids) == len(preds) == len(true), "Wrong target len!\n"
            for example_index, task_id in enumerate(task_ids):
                record_target[task_id].append(true[example_index])
                record_pred[task_id].append(preds[example_index])
        if self.test_loader.type != 'train':
            self.test_loader.reset_test_loader() # test loader iteration over reset test loader for next test
        score_dict = {}
        total_f1, total_acc = 0, 0
        assert len(tasks) == len(record_target), "dataloader tasks not equal"
        for task_id, targets in record_target.items():
            preds = record_pred[task_id]
            task_f1 = f1_score(targets, preds, average='macro')
            task_acc = accuracy_score(targets, preds)
            cls_report = classification_report(preds,targets,target_names=self.opt.polarities)
            score_dict[tasks[task_id]] = {"f1": task_f1, "acc": task_acc,"report": cls_report}
            total_f1 += task_f1
            total_acc += task_acc
        acc = total_acc / len(record_target)
        f1 = total_f1 / len(record_target)
        print('Test Acc: {} F1: {}\n'.format(acc, f1))
        return f1,acc,score_dict

    

    def run(self):
        self.train_loader = AllAspectFewshotDataLoader(self.trainset, type='train', support_size=self.opt.shots, query_size=self.opt.query_size, shuffle=True)
        self.dev_loader = AllAspectFewshotDataLoader(self.valset, type='test', support_size=self.opt.shots, query_size=self.opt.query_size, shuffle=False)
        self.test_loader = AllAspectFewshotDataLoader(self.testset, type='test', support_size=self.opt.shots, query_size=self.opt.query_size, shuffle=False)
        print("train loader length: ",len(self.train_loader))
        print("dev loader length: ",len(self.dev_loader))
        print("test loader length: ",len(self.test_loader))
        criterion = self.opt.criterion_class(opt)
        best_f1_episode, best_f1 = 0., 0.
        best_acc_episode, best_dev_acc, best_test_acc = 0., 0., 0.
        best_dev_f, best_test_f = 0., 0.
        all_episodes = self.opt.num_episode
        print("all_episodes: %d" % all_episodes)
        print('*'*40 + ' Traininng ' + '*'*40)   
      
        self.model.train() 
        with tqdm(total = all_episodes) as tqdmer:
            tqdmer.set_description('Processing:')
            for episode in range(1, all_episodes + 1):
                batch = self.train_loader.get_batch()
                input_features = [batch[feat_name].to(self.opt.device) for feat_name in self.opt.input_features]
                target = batch['polarity']
                num_support = batch['supportset_size'].item()
                target = target.to(self.opt.device)
                self.optimizer.zero_grad()
                loss, predict = self.model(input_features, target)
                _, _, acc, f1 = criterion(predict, target, num_support=num_support)
                loss.backward()
                for name, params in self.model.named_parameters():
                    torch.nn.utils.clip_grad_norm_(params, 0.3)

                self.optimizer.step()
                self.lr_scheduler.step()

                tqdmer.set_postfix(L='{:.2f}'.format(loss.item()), Acc='{:.2f}'.format(acc),  F='{:.2f}'.format(f1))
                tqdmer.update(1) 
                
                if episode % self.opt.dev_interval == 0:
                    print('*'*40 + ' Dev processing ' +'*'*40)
                    dev_f1, dev_acc = self.dev_across_tasks(episode,criterion)
                    #best_dev_acc = 0
                    '''
                    if f1 >= best_f1: ##saving best f1 model
                        best_f1_episode, best_f1 = episode, f1
                        state_dict_dir = opt.output_dir+"/state_dict"
                        if not os.path.exists(state_dict_dir):
                            os.makedirs(state_dict_dir)
                        torch.save(self.model.state_dict(), os.path.join(state_dict_dir,"best_f1_model.bin"))
                        config_path = os.path.join(self.opt.output_dir,"config.bin")
                        with open(config_path,'wb') as out_config:
                            pickle.dump(self.opt,out_config)
                    '''
                    if dev_acc > best_dev_acc: ## saving best acc model
                        best_acc_episode, best_dev_acc, best_dev_f = episode, dev_acc, dev_f1 
                        test_f1, test_acc, _ = self.test_across_tasks(criterion)
                        best_test_acc = test_acc
                        best_test_f = test_f1
                        state_dict_dir = opt.output_dir+"/state_dict"
                        if not os.path.exists(state_dict_dir):
                            os.makedirs(state_dict_dir)
                        torch.save(self.model.state_dict(), os.path.join(state_dict_dir,"best_dev_acc_model.bin"))
                        config_path = os.path.join(self.opt.output_dir,"config.bin")
                        with open(config_path,'wb') as out_config:
                            pickle.dump(self.opt,out_config)
                    
                    '''        
                    print('best_f1: ', best_f1, 'best_f1_episode: ', best_f1_episode)
                    '''
                    print('best_dev_acc: ', best_dev_acc, 'best_dev_f: ', best_dev_f, 'best_acc_episode: ', best_acc_episode)
                    print('best_test_acc: ', best_test_acc, 'best_test_f: ', best_test_f, 'best_acc_episode: ', best_acc_episode)
                    self.model.train() 
                    
                
            print()
            print()
            print(">"*40+" best test f1 evaluation "+"<"*40+"\n")
            print()
            '''
            print('The best f1 model on episode: ', best_f1_episode, ', with best f1: ', best_f1)
            ckpt = torch.load(os.path.join(state_dict_dir, "best_f1_model.bin"))
            self.model.load_state_dict(ckpt)
            f1, acc, score_dict = self.test_across_tasks(criterion)
            #print('test: ', 'f1: ', f1, 'acc: ', acc)
            self.save_evaluation_result(f1, acc, score_dict, "best_f1_result.txt")
            '''
            print()
            print(">"*40+" best test acc evaluation "+"<"*40+"\n")
            print()
            print('The best dev acc model on episode: ', best_acc_episode, ', with best dev acc: ', best_dev_acc)
            ckpt = torch.load(os.path.join(state_dict_dir, "best_dev_acc_model.bin"))
            self.model.load_state_dict(ckpt)
            test_f1, test_acc, test_score_dict = self.test_across_tasks(criterion)
            #print('test: ', 'f1: ', f1, 'acc: ', acc)
            self.save_evaluation_result(test_f1, test_acc, test_score_dict, "best_test_acc_result.txt")

    def save_evaluation_result(self,f1,acc,score_dict,file_name):
        '''
        score_dict[tasks[task_id]] = {"f1": task_f1, "acc": task_acc,"report": cls_report}
        cls_report  https://blog.csdn.net/weixin_43945848/article/details/122061718?utm_medium=distribute.pc_relevant.none-task-blog-2~default~baidujs_baidulandingword~default-0-122061718-blog-105344798.pc_relevant_multi_platform_whitelistv3&spm=1001.2101.3001.4242.1&utm_relevant_index=3
        '''
        result_path = os.path.join(self.opt.output_dir, file_name)
        with open(result_path, 'w', encoding='utf-8') as out_file:
            out_file.write('F1: {}  Test Acc: {} \nReport:\n'.format(f1, acc))
            for k in sorted(score_dict.keys()):
                scores = score_dict[k]
                for meas_name, value in scores.items():
                    out_file.write("{} {}: {}\n".format(k, meas_name, value))
                out_file.write("\n")

    def _get_tasks(self,task_path):
        tasks = []
        with open(task_path) as file:
            for line in file.readlines():
                line = line.strip()
                tasks.append(line)
        return tasks

    def _get_file_names(self,data_dir,tasks):
        return [ os.path.join(data_dir,task) for task in tasks]

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)




if __name__ == "__main__":
    # config
    parser = argparse.ArgumentParser()
    
    parser.add_argument('--device', default='cuda:1', type=str, help='e.g. cuda:0',required=False)
    parser.add_argument('--num_layers', type=int)
    parser.add_argument('--scale', type=float, help='')
    #parser.add_argument('--seed', default=42, help='123')
    parser.add_argument('--dataset', default='', type=str, help='fewshot_rest,fewshot_mams',required=False)
    parser.add_argument('--shots', type=int,required=False,help="set 1 shot; 5 shot; 10 shot")
    parser.add_argument('--n_way', type=int)
    parser.add_argument('--warmup', default= 100, type=int)
    parser.add_argument('--num_episode', default=2000, type=int, help='try larger number for non-BERT models',required=False)
    #parser.add_argument('--train_transductive', default=False, type=bool, required=False)
    parser.add_argument('--model_name', default='main_bert', type=str,required=False)
    parser.add_argument('--polarities', default=["positive", "negative"], nargs='+',required=False)
    #parser.add_argument('--polarities', default=["positive", "neutral", "negative"], nargs='+',required=False)
    parser.add_argument('--output_par_dir',default='test_outputs',type=str)
    parser.add_argument('--criterion', default='origin', type=str, help='origin or ce')
    parser.add_argument('--lr', type=float, help='try 5e-5, 2e-5, 1e-3 for others',required=False)
    #parser.add_argument('--dropout', default=0.1, type=float,required=False)
    #parser.add_argument('--l2reg', default=0.01, type=float,required=False)
    parser.add_argument('--dev_interval', default=100, type=int,required=False)
    #parser.add_argument('--hidden_dim', default=128, type=int,required=False,help="lstm encoder hidden size")
    #parser.add_argument('--output_dim', default=64, type=int,required=False)
    parser.add_argument('--relation_dim',default=100,type=int,required=False)
    parser.add_argument('--bert_dim', default=768, type=int,required=False)
    parser.add_argument('--pretrained_bert_name', default='bert-base-uncased', type=str,required=False)
    parser.add_argument('--max_seq_len', default=85, type=int,required=False)
    parser.add_argument('--query_size',default=10,type=int,required=False,help="set 20 for 1-shot; 15 for 5-shot; 10 for 10-shot")
    parser.add_argument('--iterations',default=3,type=int,required=False)
    # parser.add_argument('--hops', default=3, type=int)
    #parser.add_argument('--seed', default=42, type=int, help='set seed for reproducibility')
    #parser.add_argument('--local_context_focus', default='cdm', type=str, help='local context focus mode, cdw or cdm')
    opt = parser.parse_args()
    # os.environ["CUDA_VISIBLE_DEVICES"] = "2"
    # seed
    '''
    if opt.seed:
        set_seed(opt.seed)
    '''
    model_classes = {
        'bert-spc': BERT_SPC,
        'bert-aspect': BERT_ASPECT,
        'main_bert': main_bert
    }
    input_features = {
        'bert-spc': ['concat_bert_indices', 'concat_segments_indices', 'supportset_size'],
        'bert-aspect': ['concat_bert_indices','masked_indices', 'seed_indices','concat_segments_indices','supportset_size'],
        'main_bert': ['concat_bert_indices', 'concat_seq_len', 'concat_segments_indices', 'supportset_size'],
    }
    dataset_files = {
        'fewshot_mams_3way_1': {
            "data_dir": "./datasets/fewshot_mams_3way",
            'train': './tasks/mams/train_tasks',
            'val': "./tasks/mams/val_tasks",
            'test': './tasks/mams/test_tasks',
            'seed_files':['./seed_words/seed_words_list_entities_rest.csv','./seed_words/seed_words_list_attributes_rest.csv'],
        },'fewshot_mams_3way_2': {
            "data_dir": "./datasets/fewshot_mams_3way",
            'train': './tasks/mams/train_tasks_2',
            'val': "./tasks/mams/val_tasks_2",
            'test': './tasks/mams/test_tasks_2',
            'seed_files':['./seed_words/seed_words_list_entities_rest.csv','./seed_words/seed_words_list_attributes_rest.csv'],
        },'fewshot_mams_3way_3': {
            "data_dir": "./datasets/fewshot_mams_3way",
            'train': './tasks/mams/train_tasks_3',
            'val': "./tasks/mams/val_tasks_3",
            'test': './tasks/mams/test_tasks_3',
            'seed_files':['./seed_words/seed_words_list_entities_rest.csv','./seed_words/seed_words_list_attributes_rest.csv'],
        },'fewshot_mams_3way_4': {
            "data_dir": "./datasets/fewshot_mams_3way",
            'train': './tasks/mams/train_tasks_4',
            'val': "./tasks/mams/val_tasks_4",
            'test': './tasks/mams/test_tasks_4',
            'seed_files':['./seed_words/seed_words_list_entities_rest.csv','./seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_14rest_3way_1': {
            "data_dir": "./datasets/fewshot_14rest_3way",
            'train': './tasks/14rest/train_tasks',
            'val': "./tasks/14rest/val_tasks",
            'test': './tasks/14rest/test_tasks',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv','./seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_14rest_3way_2': {
            "data_dir": "./datasets/fewshot_14rest_3way",
            'train': './tasks/14rest/train_tasks_2',
            'val': "./tasks/14rest/val_tasks_2",
            'test': './tasks/14rest/test_tasks_2',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_14rest_3way_3': {
            "data_dir": "./datasets/fewshot_14rest_3way",
            'train': './tasks/14rest/train_tasks_3',
            'val': "./tasks/14rest/val_tasks_3",
            'test': './tasks/14rest/test_tasks_3',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_14rest_3way_4': {
            "data_dir": "./datasets/fewshot_14rest_3way",
            'train': './tasks/14rest/train_tasks_4',
            'val': "./tasks/14rest/val_tasks_4",
            'test': './tasks/14rest/test_tasks_4',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_rest_3way_1': {
            "data_dir": "./datasets/fewshot_rest_3way",
            'train': './tasks/rest_3way/train_tasks',
            'val': "./tasks/rest_3way/val_tasks",
            'test': './tasks/rest_3way/test_tasks',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_rest_3way_2': {
            "data_dir": "./datasets/fewshot_rest_3way",
            'train': './tasks/rest_3way/train_tasks_2',
            'val': "./tasks/rest_3way/val_tasks_2",
            'test': './tasks/rest_3way/test_tasks_2',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_rest_3way_3': {
            "data_dir": "./datasets/fewshot_rest_3way",
            'train': './tasks/rest_3way/train_tasks_3',
            'val': "./tasks/rest_3way/val_tasks_3",
            'test': './tasks/rest_3way/test_tasks_3',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_rest_3way_4': {
            "data_dir": "./datasets/fewshot_rest_3way",
            'train': './tasks/rest_3way/train_tasks_4',
            'val': "./tasks/rest_3way/val_tasks_4",
            'test': './tasks/rest_3way/test_tasks_4',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },'fewshot_rest_3way_5': {
            "data_dir": "./datasets/fewshot_rest_3way",
            'train': './tasks/rest_3way/train_tasks_5',
            'val': "./tasks/rest_3way/val_tasks_5",
            'test': './tasks/rest_3way/test_tasks_5',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_lap_3way_1': {
            "data_dir": "./datasets/fewshot_lap_3way",
            'train': './tasks/lap_3way/train_tasks',
            'val': "./tasks/lap_3way/val_tasks",
            'test': './tasks/lap_3way/test_tasks',
            'seed_files': ['./seed_words/seed_words_list_entities_lap.csv','./seed_words/seed_words_list_attributes_lap.csv'],
        },'fewshot_lap_3way_2': {
            "data_dir": "./datasets/fewshot_lap_3way",
            'train': './tasks/lap_3way/train_tasks_2',
            'val': "./tasks/lap_3way/val_tasks_2",
            'test': './tasks/lap_3way/test_tasks_2',
            'seed_files': ['./seed_words/seed_words_list_entities_lap.csv','./seed_words/seed_words_list_attributes_lap.csv'],
        },
        'fewshot_lap_3way_3': {
            "data_dir": "./datasets/fewshot_lap_3way",
            'train': './tasks/lap_3way/train_tasks_3',
            'val': "./tasks/lap_3way/val_tasks_3",
            'test': './tasks/lap_3way/test_tasks_3',
            'seed_files': ['./seed_words/seed_words_list_entities_lap.csv',
                           './seed_words/seed_words_list_attributes_lap.csv'],
        },'fewshot_lap_3way_4': {
            "data_dir": "./datasets/fewshot_lap_3way",
            'train': './tasks/lap_3way/train_tasks_4',
            'val': "./tasks/lap_3way/val_tasks_4",
            'test': './tasks/lap_3way/test_tasks_4',
            'seed_files': ['./seed_words/seed_words_list_entities_lap.csv',
                           './seed_words/seed_words_list_attributes_lap.csv'],
        },
        'fewshot_mams_2way_1': {
            "data_dir": "./datasets/fewshot_mams_2way",
            'train': './tasks/mams/train_tasks',
            'val': "./tasks/mams/val_tasks",
            'test': './tasks/mams/test_tasks',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        }, 'fewshot_mams_2way_2': {
            "data_dir": "./datasets/fewshot_mams_2way",
            'train': './tasks/mams/train_tasks_2',
            'val': "./tasks/mams/val_tasks_2",
            'test': './tasks/mams/test_tasks_2',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        }, 'fewshot_mams_2way_3': {
            "data_dir": "./datasets/fewshot_mams_2way",
            'train': './tasks/mams/train_tasks_3',
            'val': "./tasks/mams/val_tasks_3",
            'test': './tasks/mams/test_tasks_3',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        }, 'fewshot_mams_2way_4': {
            "data_dir": "./datasets/fewshot_mams_2way",
            'train': './tasks/mams/train_tasks_4',
            'val': "./tasks/mams/val_tasks_4",
            'test': './tasks/mams/test_tasks_4',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },'fewshot_rest_2way_1': {
            "data_dir": "./datasets/fewshot_rest_2way",
            'train': './tasks/rest_2way/train_tasks',
            'val': "./tasks/rest_2way/val_tasks",
            'test': './tasks/rest_2way/test_tasks',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_rest_2way_2': {
            "data_dir": "./datasets/fewshot_rest_2way",
            'train': './tasks/rest_2way/train_tasks_2',
            'val': "./tasks/rest_2way/val_tasks_2",
            'test': './tasks/rest_2way/test_tasks_2',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_rest_2way_3': {
            "data_dir": "./datasets/fewshot_rest_2way",
            'train': './tasks/rest_2way/train_tasks_3',
            'val': "./tasks/rest_2way/val_tasks_3",
            'test': './tasks/rest_2way/test_tasks_3',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_rest_2way_4': {
            "data_dir": "./datasets/fewshot_rest_2way",
            'train': './tasks/rest_2way/train_tasks_4',
            'val': "./tasks/rest_2way/val_tasks_4",
            'test': './tasks/rest_2way/test_tasks_4',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_lap_2way_1': {
            "data_dir": "./datasets/fewshot_lap_2way",
            'train': './tasks/lap_2way/train_tasks',
            'val': "./tasks/lap_2way/val_tasks",
            'test': './tasks/lap_2way/test_tasks',
            'seed_files': ['./seed_words/seed_words_list_entities_lap.csv','./seed_words/seed_words_list_attributes_lap.csv'],
        },'fewshot_lap_2way_2': {
            "data_dir": "./datasets/fewshot_lap_2way",
            'train': './tasks/lap_2way/train_tasks_2',
            'val': "./tasks/lap_2way/val_tasks_2",
            'test': './tasks/lap_2way/test_tasks_2',
            'seed_files': ['./seed_words/seed_words_list_entities_lap.csv','./seed_words/seed_words_list_attributes_lap.csv'],
        },
        'fewshot_lap_2way_3': {
            "data_dir": "./datasets/fewshot_lap_2way",
            'train': './tasks/lap_2way/train_tasks_3',
            'val': "./tasks/lap_2way/val_tasks_3",
            'test': './tasks/lap_2way/test_tasks_3',
            'seed_files': ['./seed_words/seed_words_list_entities_lap.csv',
                           './seed_words/seed_words_list_attributes_lap.csv'],
        },'fewshot_lap_2way_4': {
            "data_dir": "./datasets/fewshot_lap_2way",
            'train': './tasks/lap_2way/train_tasks_4',
            'val': "./tasks/lap_2way/val_tasks_4",
            'test': './tasks/lap_2way/test_tasks_4',
            'seed_files': ['./seed_words/seed_words_list_entities_lap.csv',
                           './seed_words/seed_words_list_attributes_lap.csv'],
        },
        'fewshot_14rest_2way_1': {
            "data_dir": "./datasets/fewshot_14rest_2way",
            'train': './tasks/14rest/train_tasks',
            'val': "./tasks/14rest/val_tasks",
            'test': './tasks/14rest/test_tasks',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv','./seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_14rest_2way_2': {
            "data_dir": "./datasets/fewshot_14rest_2way",
            'train': './tasks/14rest/train_tasks_2',
            'val': "./tasks/14rest/val_tasks_2",
            'test': './tasks/14rest/test_tasks_2',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_14rest_2way_3': {
            "data_dir": "./datasets/fewshot_14rest_2way",
            'train': './tasks/14rest/train_tasks_3',
            'val': "./tasks/14rest/val_tasks_3",
            'test': './tasks/14rest/test_tasks_3',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        },
        'fewshot_14rest_2way_4': {
            "data_dir": "./datasets/fewshot_14rest_2way",
            'train': './tasks/14rest/train_tasks_4',
            'val': "./tasks/14rest/val_tasks_4",
            'test': './tasks/14rest/test_tasks_4',
            'seed_files': ['./seed_words/seed_words_list_entities_rest.csv',
                           './seed_words/seed_words_list_attributes_rest.csv'],
        }
    }
    criterions = {
        'origin': Criterion,
        'ce':CrossEntropyCriterion,
    }
    
    opt.device = 'cuda:3'
    opt.dataset = 'fewshot_rest_2way_4'
    opt.num_layers = 2
    opt.n_way = 2
    opt.shots = 1
    opt.model_class = model_classes[opt.model_name]
    opt.dataset_files = dataset_files[opt.dataset]
    opt.criterion_class = criterions[opt.criterion]
    opt.input_features = input_features[opt.model_name]
    opt.output_dir = os.path.join(opt.output_par_dir,opt.model_name,str(opt.shots),opt.dataset) ##get output directory to save results
    opt.ways = len(opt.polarities)
    assert opt.n_way == opt.ways
    if not os.path.exists(opt.output_dir):
        os.makedirs(opt.output_dir)
    scale = [0.8, 0.8, 0.6, 0.6, 0.4, 0.4, 0.2, 0.2]
    lr = [2e-5, 5e-5, 2e-5, 5e-5, 2e-5, 5e-5, 2e-5, 5e-5]
    for i in range(8):
        opt.scale = scale[i]
        opt.lr = lr[i]
        print(opt.num_layers)
        print(opt.scale)
        print(opt.lr)
        ins = Instructor(opt)
        ins.run()
        print('hi')



